package com.pojo;

public class Emp_Pojo 
{
	int Empno1;
	String Empname;
	float salary1;
	public int getEmpno1() {
		return Empno1;
	}
	public void setEmpno1(int empno1) {
		Empno1 = empno1;
	}
	public String getEmpname() {
		return Empname;
	}
	public void setEmpname(String empname) {
		Empname = empname;
	}
	public float getSalary1() {
		return salary1;
	}
	public void setSalary1(float salary1) {
		this.salary1 = salary1;
	}
	

}
