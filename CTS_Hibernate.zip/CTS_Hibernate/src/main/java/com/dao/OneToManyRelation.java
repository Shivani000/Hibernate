package com.dao;



import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.CustomerPojo;
import com.pojo.VendorPojo;

public class OneToManyRelation {

	public static void main(String[] args) 
	{
		Session s = new Configuration().configure("cts_hibernate.cfg.xml").buildSessionFactory().openSession();
		Transaction t=s.beginTransaction();
		VendorPojo v = new VendorPojo();
		v.setVid1(10);
		v.setVname1("ZoHO");
		v.setEmail("admin@zoho.com");
		
		CustomerPojo c1 = new CustomerPojo();
		c1.setCustid(45);
		c1.setCustname("Bajaj");
		

		CustomerPojo c2 = new CustomerPojo();
		c2.setCustid(46);
		c2.setCustname("Shivani");
		
		Set s11 = new HashSet();
		s11.add(c1);
		s11.add(c2);
		
		v.setCust1(s11); //one Vendor to many customers
		s.save(v);//s.persist()
		t.commit();
		s.close();
		System.out.println("One To Many Done");		
	}

}
