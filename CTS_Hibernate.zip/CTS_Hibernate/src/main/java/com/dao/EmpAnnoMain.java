package com.dao;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.EmpPojo_Annotation;
import com.pojo.Emp_Pojo;

public class EmpAnnoMain {

	public static void main(String[] args) 
	{
		Session s = new Configuration().configure("cts_hibernate.cfg.xml").buildSessionFactory().openSession();
		//Session session = s.openSession();
		
		//start a transaction
		Transaction tx = s.beginTransaction();
		EmpPojo_Annotation e1 = new EmpPojo_Annotation();
		Scanner sacn = new Scanner(System.in);
		System.out.println("Eno :");
		int eno1 = sacn.nextInt();
		System.out.println("Ename :");
		String name1 = sacn.next();
		System.out.println("Salary :");
		float salary1 = sacn.nextFloat();
		
		e1.setEmp_num(eno1);
		e1.setEmp_name(name1);
		e1.setEmp_salary(salary1);
		
		//upto emp_pojo is transient state
		//persist == insert into tablename values
		s.persist(e1); //persistent state or saving POJO object
		System.out.println("**** Inserted *****");
		
		//without commit not reflected in database
		tx.commit(); //commit or save the query

	}

}
